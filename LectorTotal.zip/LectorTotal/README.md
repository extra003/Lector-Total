# Lector Total — proyecto Android inicial

Esta es una primera versión de código fuente para abrir archivos PDF con texto seleccionable y TXT, mostrarlos como texto y leerlos en voz alta usando el motor TTS instalado en Android.

## Abrir el proyecto
1. Instala Android Studio en un ordenador.
2. Descomprime este ZIP y abre la carpeta `LectorTotal` en Android Studio.
3. Espera a que Gradle sincronice las dependencias (la primera compilación necesita internet).
4. Conecta el teléfono Android con depuración USB habilitada o usa un emulador.
5. Pulsa Run para probar la aplicación.

## Voces sin conexión
La app no descarga voces automáticamente. Usa las voces instaladas en Android y muestra si una voz informa que necesita conexión.
En el OPPO, abre Ajustes y busca “Texto a voz” o “Salida de texto a voz”. Selecciona el motor disponible, entra en instalar/descargar datos de voz y descarga español. El nombre exacto del menú depende de la versión de ColorOS y del motor instalado. Después abre la app y selecciona una voz marcada como local.

## Limitaciones de esta versión inicial
- No es un APK compilado; es el proyecto fuente para abrir y compilar con Android Studio.
- Los PDF se extraen y muestran como texto; no se conserva su diseño visual de página.
- Los PDF escaneados requieren OCR, que todavía no está integrado.
- EPUB, DOCX y RTF todavía no están implementados.
- La reproducción en segundo plano con controles de notificación aún no está implementada.
- La disponibilidad de voces depende del motor de síntesis instalado en el teléfono. La app no incluye ni clona la voz propietaria Sabina.
