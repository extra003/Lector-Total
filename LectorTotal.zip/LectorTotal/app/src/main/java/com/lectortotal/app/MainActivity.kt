package com.lectortotal.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private lateinit var title: TextView
    private lateinit var content: TextView
    private lateinit var speed: SeekBar
    private lateinit var voiceSpinner: Spinner
    private var fullText = ""
    private var currentUri: Uri? = null
    private var ttsReady = false
    private var voices: List<android.speech.tts.Voice> = emptyList()
    private var chunkIndex = 0
    private var chunks: List<String> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 12)
            setBackgroundColor(0xFFF4F6F8.toInt())
        }
        val header = TextView(this).apply {
            text = "LECTOR TOTAL\nTu biblioteca personal"
            textSize = 23f
            setTextColor(0xFF17394B.toInt())
            gravity = Gravity.CENTER_VERTICAL
            setPadding(4, 4, 4, 16)
        }
        root.addView(header)
        val importButton = Button(this).apply { text = "＋  Abrir PDF o texto"; setOnClickListener { openFile() } }
        root.addView(importButton)
        title = TextView(this).apply { text = "Ningún documento abierto"; textSize = 17f; setTextColor(0xFF17394B.toInt()); setPadding(2, 12, 2, 6) }
        root.addView(title)
        status = TextView(this).apply { text = "Voz: comprobando motores disponibles…"; textSize = 13f; setTextColor(0xFF52636B.toInt()); setPadding(2, 2, 2, 8) }
        root.addView(status)
        voiceSpinner = Spinner(this)
        root.addView(voiceSpinner)
        val voiceSettings = Button(this).apply {
            text = "Configurar / descargar voces sin conexión"
            setOnClickListener {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                catch (_: Exception) { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            }
        }
        root.addView(voiceSettings)
        val speedLabel = TextView(this).apply { text = "Velocidad de lectura"; setTextColor(0xFF17394B.toInt()); setPadding(2, 8, 2, 0) }
        root.addView(speedLabel)
        speed = SeekBar(this).apply { max = 15; progress = 5 }
        root.addView(speed)
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        controls.addView(Button(this).apply { text = "▶ Leer"; setOnClickListener { startReading() } }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply { text = "Ⅱ Pausar"; setOnClickListener { if (ttsReady) tts.stop(); status.text = "Lectura pausada" } }, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(Button(this).apply { text = "■ Detener"; setOnClickListener { if (ttsReady) tts.stop(); chunkIndex = 0; status.text = "Lectura detenida" } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(controls)
        content = TextView(this).apply {
            text = "Abre un PDF o un archivo TXT para comenzar. Los archivos permanecen en tu dispositivo.\n\nNota: en esta primera versión, los PDF con texto seleccionable se convierten a texto para leerlos en voz alta."
            textSize = 18f
            setTextColor(0xFF202B30.toInt())
            setPadding(14, 14, 14, 20)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/pdf", "text/plain", "text/*"))
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Deprecated by platform but sufficient for this small starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 100 || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        currentUri = uri
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        try {
            val name = queryName(uri) ?: "Documento"
            val text = when {
                name.lowercase(Locale.ROOT).endsWith(".pdf") || contentResolver.getType(uri) == "application/pdf" -> extractPdf(uri)
                else -> readText(uri)
            }
            if (text.isBlank()) throw IllegalArgumentException("No se encontró texto legible. Si el PDF es un escaneo, necesita OCR.")
            fullText = text
            chunks = splitText(text)
            chunkIndex = 0
            title.text = name
            content.text = text
            status.text = "Documento listo · ${chunks.size} fragmentos de lectura"
        } catch (e: Exception) {
            status.text = "No se pudo abrir: ${e.message ?: "formato no compatible"}"
        }
    }

    private fun queryName(uri: Uri): String? {
        val cursor = contentResolver.query(uri, null, null, null, null) ?: return null
        cursor.use {
            val index = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (it.moveToFirst() && index >= 0) return it.getString(index)
        }
        return null
    }

    private fun readText(uri: Uri): String = contentResolver.openInputStream(uri)?.use { input ->
        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
    } ?: ""

    private fun extractPdf(uri: Uri): String {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return ""
        PDDocument.load(bytes).use { document -> return PDFTextStripper().getText(document) }
    }

    private fun splitText(text: String): List<String> {
        val paragraphs = text.replace("\r", "").split(Regex("\\n\\s*\\n"))
        val result = mutableListOf<String>()
        val current = StringBuilder()
        for (p in paragraphs) {
            if (current.length + p.length > 2500 && current.isNotEmpty()) {
                result.add(current.toString()); current.clear()
            }
            if (p.length > 2500) {
                p.chunked(2000).forEach { result.add(it) }
            } else {
                if (current.isNotEmpty()) current.append("\n\n")
                current.append(p)
            }
        }
        if (current.isNotEmpty()) result.add(current.toString())
        return result.filter { it.isNotBlank() }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode != TextToSpeech.SUCCESS) {
            status.text = "No se pudo iniciar el motor de voz del teléfono."
            return
        }
        ttsReady = true
        val result = tts.setLanguage(Locale("es", "ES"))
        voices = tts.voices?.filter { it.locale.language == "es" }?.sortedWith(compareBy<android.speech.tts.Voice>({ !it.name.contains("female", true) }, { it.name })) ?: emptyList()
        val labels = if (voices.isEmpty()) listOf("Voz española predeterminada del teléfono") else voices.map { voice ->
            val offline = if (voice.isNetworkConnectionRequired) " · requiere internet" else " · local" 
            voice.name + offline
        }
        runOnUiThread {
            voiceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
            status.text = when (result) {
                TextToSpeech.LANG_MISSING_DATA, TextToSpeech.LANG_NOT_SUPPORTED -> "Falta una voz española. Abre los ajustes de voz y descarga español."
                else -> "Motor de voz listo. Elige una voz local para escuchar sin internet."
            }
        }
    }

    private fun startReading() {
        if (!ttsReady) { status.text = "El motor de voz todavía no está listo."; return }
        if (chunks.isEmpty()) { status.text = "Primero abre un PDF o un archivo de texto."; return }
        if (voices.isNotEmpty() && voiceSpinner.selectedItemPosition in voices.indices) {
            val selected = voices[voiceSpinner.selectedItemPosition]
            tts.voice = selected
            if (selected.isNetworkConnectionRequired) status.text = "Aviso: esta voz requiere internet; selecciona una marcada como local para uso sin conexión."
        }
        tts.setSpeechRate(0.5f + (speed.progress * 0.1f))
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { }
            override fun onDone(utteranceId: String?) {
                val next = utteranceId?.toIntOrNull()?.plus(1) ?: return
                if (next < chunks.size) {
                    chunkIndex = next
                    runOnUiThread { status.text = "Leyendo fragmento ${next + 1} de ${chunks.size}" }
                    tts.speak(chunks[next], TextToSpeech.QUEUE_ADD, null, next.toString())
                } else runOnUiThread { status.text = "Lectura terminada" }
            }
            override fun onError(utteranceId: String?) { runOnUiThread { status.text = "Error al sintetizar la voz." } }
        })
        status.text = "Leyendo fragmento ${chunkIndex + 1} de ${chunks.size}"
        tts.speak(chunks[chunkIndex], TextToSpeech.QUEUE_FLUSH, null, chunkIndex.toString())
    }

    override fun onDestroy() {
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
