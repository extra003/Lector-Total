plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lectortotal.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.lectortotal.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
